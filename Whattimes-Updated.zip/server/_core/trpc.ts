import { initTRPC } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context.js";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

// Auth removed
export const protectedProcedure = t.procedure;
export const adminProcedure = t.procedure;
